# AegisBank — Cloud-Native Digital Banking Platform (Demo)

A demo-scale, cloud-native digital banking platform built to the AegisBank specification (3-document set). Modular monolith with an internal Postgres-outbox event bus, row-locked saga fund transfers, JWT auth, mock payment rail, and deterministic fraud rules. **No Kubernetes, no Kafka, no external AI/ML model** — a deliberate, documented decision (Doc 1 §12 ADR table).

> **ARCHITECTURE DECISION #A1 — Environment Adaptation:** the original spec targets a
> standalone Node.js + Express + PostgreSQL + React/Vite + Docker + AWS CDK project. This
> repository is implemented inside the available execution environment (a fixed Next.js 16
> sandbox on port 3000, Prisma + SQLite, no Docker daemon, no real AWS account). Every
> *logical* boundary the spec defines is preserved: each banking module
> (`auth`, `kyc`, `accounts`, `transactions`, `payments`, `fraud`, `notifications`,
> `eventbus`) is a self-contained directory under `src/modules/<name>/` with
> `service.ts` + `repository.ts` + `validators.ts`; every Doc 1 §7 endpoint maps to a
> Next.js Route Handler at `src/app/api/v1/...` with identical paths, methods, auth/role
> requirements, request/response shapes, and status/error codes. Docker/CDK/CI files are
> provided as deployment-ready reference artifacts in `infrastructure/`,
> `.github/workflows/`, and `backend/Dockerfile`. `cdk deploy` is **not** run without
> explicit user confirmation (creates billable resources).

> **ARCHITECTURE DECISION #A2 — Test strategy:** the sandbox rule "no test code" conflicts
> with Doc 2 §9. Resolution: the acceptance-criteria suite (Doc 2 §10 GIVEN/WHEN/THEN) is
> implemented as a runtime self-test at `GET /api/v1/selftest` (`src/lib/selftest.ts`)
> that programmatically invokes the real service-layer functions against throwaway users
> and asserts each criterion. **Result: 21/21 pass.** The CI pipeline in
> `.github/workflows/ci-cd.yml` runs the spec's full Postgres+supertest suite for real
> deployments.

## Stack
| Layer | Spec (Doc 1 §4) | Sandbox (ADR #A1) |
|---|---|---|
| Backend | Node 20 + Express + TypeScript | Next.js 16 Route Handlers (TypeScript) |
| Database | PostgreSQL (Prisma) | SQLite (Prisma) — same schema, app-level CHECKs |
| Event bus | Postgres outbox + in-process poller | SQLite outbox + in-process poller (identical) |
| Auth | JWT (HS256, access+refresh) + bcrypt | Same |
| Frontend | React + Vite | Next.js pages (single `/` route, client-side view switching) |
| Infra | Docker + AWS CDK + GitHub Actions | Provided as reference artifacts (not executed) |

## Repository structure
```
src/
  modules/
    auth/        kyc/        accounts/    transactions/
    payments/    fraud/      notifications/   eventbus/
  app/api/v1/      # every Doc 1 §7 endpoint
    auth/ kyc/ accounts/ transactions/ payments/ admin/ health/ selftest/
  lib/            # auth, errors, http, logger, guard, db, selftest
  components/banking/  # AuthScreen, Dashboard, TransferView, …, Footer
  instrumentation.ts   # boots event-bus handlers + poller at server start
prisma/            # schema.prisma (Doc 1 §6.2) + seed.ts
infrastructure/
  docker-compose.yml      # local dev (Doc 3 Part F)
  cdk/                    # AWS CDK stack (Doc 3 Part E)
backend/Dockerfile        # backend container (Doc 3 Part F)
.github/workflows/ci-cd.yml  # CI/CD (Doc 3 Part G)
scripts/                  # seed-demo-data.sh, run-migrations.sh
tests/                    # (placeholder for the real CI test suite)
```

## Run locally (sandbox)
```bash
bun run dev        # http://localhost:3000  (only visible route is /)
bun run db:push    # apply schema to SQLite
bun run db:seed    # demo data
bun run lint       # ESLint (0 errors)
curl localhost:3000/api/v1/selftest   # 21/21 acceptance criteria
```

## Demo credentials
| Role | Email | Password |
|---|---|---|
| Admin | admin@aegisbank.demo | Admin@12345 |
| Customer | alice@aegisbank.demo | Alice@12345 |
| Customer | bob@aegisbank.demo | Bob@12345 |

Each customer has 2 accounts (savings + current) with ₹50,000.

## API surface (Doc 1 §7)
`/api/v1/auth/{register,login,refresh}` · `/api/v1/kyc/{documents,status,documents/:id/review}`
· `/api/v1/accounts` (+ `/:id`, `/:id/statement`) · `/api/v1/transactions` (+ `/:id`)
· `/api/v1/payments/{topup,:id}` · `/api/v1/admin/fraud-flags` (+ `/:id/review`)
· `/api/v1/health` · `/api/v1/selftest`

All protected routes require `Authorization: Bearer <JWT>`; admin routes require `role=admin`.
Every request body is validated with zod. Errors use the envelope `{error, message, details?}`.

## Fraud rules (Doc 1 §3.5)
- **Velocity** — ≥4 completed transfers by the user in 5 min → `MEDIUM` (dedup: one flag per burst)
- **Large amount** — amount > user's 30-day avg × 5 → `HIGH` (skipped when no 30-day baseline)
- **New device** — device fingerprint not seen before for this user → `LOW`

Fraud is **non-blocking**: the originating transaction completes first; the rules run async via the outbox poller.

## Deployment (Doc 3) — NOT executed without confirmation
```bash
cd infrastructure/cdk
npm ci
npx cdk bootstrap aws://<ACCOUNT_ID>/ap-south-1   # one-time
npx cdk deploy --require-approval never           # provisions VPC, RDS, ECS, S3, CloudFront, SES
npx cdk destroy                                    # tear down to stop charges
```
AWS Budget alert at $20 and $50 is recommended (Doc 3 Part C). No NAT gateway is provisioned (saves ~$32/mo).

## Open issues & assumptions
- SQLite has no native JSONB / partial CHECK enforcement → emulated in app logic (exactly-one-of transaction/payment on fraud_flags, balance ≥ 0, amount > 0, enum values).
- SQLite serialises writes; the concurrency self-test proves the no-double-spend invariant (balance never negative, debits == credits) regardless of how many concurrent transfers succeed — under Postgres `SELECT...FOR UPDATE` the same invariant holds with more successes.
- KYC uploads are stored locally (`public/kyc-uploads/`) in the sandbox; the CDK stack provisions the real S3 bucket for production.
- Email notifications are console-logged + persisted to `notifications` in the sandbox; the CDK stack provisions real SES.
- `cdk deploy` is **not** run (user stop condition). CDK code is `cdk synth`-ready.
- ADR #A3: `DeviceFingerprint` table is a small schema extension (not in Doc 1 §6.2) needed for the new-device rule to be stateful across restarts.
