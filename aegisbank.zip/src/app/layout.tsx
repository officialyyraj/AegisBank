import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "AegisBank — Cloud-Native Digital Banking",
  description: "AegisBank: a demo-scale modular-monolith digital banking platform with Postgres-outbox event bus, row-locked saga transfers, and deterministic fraud rules.",
  keywords: ["AegisBank", "banking", "Next.js", "TypeScript", "Prisma", "AWS CDK", "modular monolith"],
  authors: [{ name: "AegisBank" }],
  icons: {
    icon: "/logo.svg",
  },
  openGraph: {
    title: "AegisBank — Cloud-Native Digital Banking",
    description: "Modular monolith · outbox event bus · row-locked transfers · fraud rules",
    siteName: "AegisBank",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "AegisBank",
    description: "Cloud-native digital banking demo platform",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        {children}
        <Toaster />
      </body>
    </html>
  );
}
