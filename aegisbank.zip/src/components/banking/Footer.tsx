// src/components/banking/Footer.tsx — sticky footer with system status.
'use client'
import { useEffect, useState } from 'react'
import { Activity, Github, ShieldCheck } from 'lucide-react'
import { api } from '@/lib/frontend/api'

export function Footer() {
  const [events, setEvents] = useState<{ pending: number; processed: number; failed: number } | null>(null)

  useEffect(() => {
    let alive = true
    const tick = async () => {
      try {
        const h = await api.health()
        if (alive && h.events) setEvents(h.events)
      } catch { /* ignore */ }
    }
    void tick()
    const id = setInterval(tick, 10000)
    return () => { alive = false; clearInterval(id) }
  }, [])

  return (
    <footer className="mt-auto border-t bg-card/60 backdrop-blur">
      <div className="mx-auto flex max-w-6xl flex-col items-center justify-between gap-3 px-4 py-4 text-xs text-muted-foreground sm:flex-row">
        <div className="flex items-center gap-2">
          <ShieldCheck className="size-3.5 text-primary" />
          <span>AegisBank · modular monolith · outbox event bus · {new Date().getFullYear()}</span>
        </div>
        <div className="flex items-center gap-4">
          <span className="flex items-center gap-1.5">
            <Activity className="size-3.5 text-primary" />
            Outbox:
            {events ? (
              <span className="font-mono">
                {events.processed} processed · {events.pending} pending{events.failed ? ` · ${events.failed} failed` : ''}
              </span>
            ) : (
              <span className="font-mono">…</span>
            )}
          </span>
          <span className="flex items-center gap-1">
            <Github className="size-3.5" /> AWS CDK · GitHub Actions
          </span>
        </div>
      </div>
    </footer>
  )
}
