// src/components/banking/SelfTestView.tsx — run the acceptance suite (ADR #A2).
'use client'
import { useState } from 'react'
import { motion } from 'framer-motion'
import { Play, CheckCircle2, XCircle, Loader2, FlaskConical } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { SectionCard, ErrorBanner } from './primitives'

interface Report { total: number; passed: number; failed: number; results: { name: string; pass: boolean; detail?: string }[]; durationMs: number }

export function SelfTestView() {
  const [report, setReport] = useState<Report | null>(null)
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState<string | null>(null)

  async function run() {
    setBusy(true); setError(null); setReport(null)
    try {
      const r = await fetch('/api/v1/selftest')
      const body = await r.json()
      if (!r.ok) throw new Error(body?.message || `HTTP ${r.status}`)
      setReport(body)
    } catch (e) {
      setError((e as Error).message)
    } finally {
      setBusy(false)
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between gap-3">
        <div>
          <h2 className="text-lg font-semibold flex items-center gap-2"><FlaskConical className="size-5 text-primary" /> Acceptance test suite</h2>
          <p className="text-sm text-muted-foreground">Runs the 21 GIVEN/WHEN/THEN criteria from Doc 2 §10 against throwaway users.</p>
        </div>
        <Button onClick={run} disabled={busy}>
          {busy ? <><Loader2 className="size-4 animate-spin" /> Running…</> : <><Play className="size-4" /> Run tests</>}
        </Button>
      </div>

      {error && <ErrorBanner message={error} />}

      {report && (
        <motion.div initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} className="space-y-4">
          <div className="grid gap-3 sm:grid-cols-4">
            <Stat label="Total" value={report.total} tone="muted" />
            <Stat label="Passed" value={report.passed} tone="primary" />
            <Stat label="Failed" value={report.failed} tone={report.failed === 0 ? 'primary' : 'destructive'} />
            <Stat label="Duration" value={`${(report.durationMs / 1000).toFixed(1)}s`} tone="muted" />
          </div>

          <SectionCard title="Results" description="Per-criterion pass/fail">
            <ul className="space-y-1.5 max-h-[34rem] overflow-y-auto scroll-thin pr-1">
              {report.results.map((r) => (
                <li key={r.name} className="flex items-start gap-2 rounded-md border bg-card p-2 text-sm">
                  {r.pass ? <CheckCircle2 className="mt-0.5 size-4 shrink-0 text-primary" /> : <XCircle className="mt-0.5 size-4 shrink-0 text-destructive" />}
                  <div className="min-w-0">
                    <span className="font-medium">{r.name}</span>
                    {r.detail && <p className="text-xs text-muted-foreground font-mono break-all">{r.detail}</p>}
                  </div>
                  <Badge variant={r.pass ? 'secondary' : 'destructive'} className="ml-auto text-[10px]">{r.pass ? 'PASS' : 'FAIL'}</Badge>
                </li>
              ))}
            </ul>
          </SectionCard>
        </motion.div>
      )}

      {!report && !busy && !error && (
        <SectionCard title="Not run yet" description="Click ‘Run tests’ to verify the full acceptance suite">
          <p className="text-sm text-muted-foreground py-8 text-center">
            The suite registers a throwaway user, exercises register/login/refresh, the KYC gate, the
            transfer saga, outbox events, insufficient-funds, same-src-dst rejection, concurrency
            no-double-spend, top-up, fraud velocity, and admin review.
          </p>
        </SectionCard>
      )}
    </div>
  )
}

function Stat({ label, value, tone }: { label: string; value: number | string; tone: 'primary' | 'destructive' | 'muted' }) {
  const c = { primary: 'text-primary', destructive: 'text-destructive', muted: 'text-muted-foreground' }[tone]
  return (
    <div className="rounded-xl border bg-card p-3">
      <p className="text-xs font-medium uppercase text-muted-foreground">{label}</p>
      <p className={`text-2xl font-semibold ${c}`}>{value}</p>
    </div>
  )
}
