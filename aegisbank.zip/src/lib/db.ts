import { PrismaClient } from '@prisma/client'

const globalForPrisma = globalThis as unknown as {
  prisma: PrismaClient | undefined
}

// ADR #A16/#A19: disabled `log: ['query']` (was adding overhead under concurrent
// load, contributing to socket timeouts). The default socket timeout is 5s
// which is too short for SQLite under concurrent writes (outbox poller +
// transfer requests competing for the single writer). We set a generous
// `transactionOptions` default so all transactions get 30s unless overridden.
//
// ADR #A19: SQLite pragma tuning — set `journal_mode=WAL` (write-ahead logging
// allows concurrent readers + a single writer, dramatically reducing SQLITE_BUSY
// under load) + `busy_timeout=30000` (wait up to 30s for a lock instead of
// throwing SQLITE_BUSY immediately). Applied once at client construction via
// `$transaction` raw queries.
export const db =
  globalForPrisma.prisma ??
  (() => {
    const client = new PrismaClient({
      log: process.env.NODE_ENV === 'production' ? ['error'] : ['error', 'warn'],
      transactionOptions: { maxWait: 10000, timeout: 30000, isolationLevel: 'Serializable' },
    })
    // Apply SQLite pragmas once. These are no-ops on Postgres (production).
    void client.$executeRawUnsafe('PRAGMA journal_mode=WAL').catch(() => { /* ignore on non-SQLite */ })
    void client.$executeRawUnsafe('PRAGMA busy_timeout=30000').catch(() => { /* ignore */ })
    void client.$executeRawUnsafe('PRAGMA synchronous=NORMAL').catch(() => { /* ignore — WAL-safe perf tradeoff */ })
    return client
  })()

if (process.env.NODE_ENV !== 'production') globalForPrisma.prisma = db
