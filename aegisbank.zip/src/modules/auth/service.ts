// src/modules/auth/service.ts — register/login/refresh business logic (Doc 2 §3).
import { authRepository } from './repository'
import {
  hashPassword,
  verifyPassword,
  signAccessToken,
  signRefreshToken,
  verifyRefreshToken,
  ACCESS_TTL,
} from '@/lib/auth'
import { Errors } from '@/lib/errors'
import { logger } from '@/lib/logger'
import { db } from '@/lib/db'
import { Prisma } from '@prisma/client'

// ADR #A27: refresh-token rotation. JWTs are stateless, so to enforce
// single-use refresh tokens we track consumed JTIs in an in-memory Set.
// On restart, all old refresh tokens become invalid (acceptable for demo;
// production would use Redis or a DB table). This prevents token replay.
const consumedRefreshJtis = new Set<string>()

/** Register a new customer. Admins are seeded/created via direct DB (Doc 3 Part K step 12). */
export async function register(input: { email: string; password: string; full_name: string }) {
  const existing = await authRepository.findByEmail(input.email)
  if (existing) throw Errors.conflict('Email already registered')
  const passwordHash = await hashPassword(input.password)
  try {
    const user = await authRepository.createUser({
      email: input.email,
      passwordHash,
      fullName: input.full_name,
      role: 'customer',
      kycStatus: 'pending',
    })
    logger.info('auth.register.success', { userId: user.id })
    return { user_id: user.id }
  } catch (e) {
    // race: created between our check & insert
    if (e instanceof Prisma.PrismaClientKnownRequestError && e.code === 'P2002') {
      throw Errors.conflict('Email already registered')
    }
    throw e
  }
}

/** Verify credentials and issue access + refresh tokens. */
export async function login(input: { email: string; password: string }) {
  const user = await authRepository.findByEmail(input.email)
  if (!user) {
    // generic 401 — no user enumeration (Doc 1 §9)
    throw Errors.unauthorized('Invalid credentials')
  }
  const valid = await verifyPassword(input.password, user.passwordHash)
  if (!valid) throw Errors.unauthorized('Invalid credentials')
  const { token: access_token, expiresIn } = signAccessToken({ id: user.id, email: user.email, role: user.role })
  const refresh_token = signRefreshToken({ id: user.id, email: user.email, role: user.role })
  logger.info('auth.login.success', { userId: user.id, role: user.role })
  return { access_token, refresh_token, expires_in: expiresIn }
}

/**
 * Verify a refresh token and issue a fresh access token + a NEW refresh token
 * (rotation). The old refresh token's JTI is consumed (added to the in-memory
 * consumed set) so it can't be reused. ADR #A27.
 */
export async function refresh(refresh_token: string) {
  const decoded = verifyRefreshToken(refresh_token)
  // Check if this refresh token has already been consumed (rotation)
  if (decoded.jti && consumedRefreshJtis.has(decoded.jti)) {
    throw Errors.unauthorized('Refresh token already used')
  }
  // Consume the old JTI
  if (decoded.jti) {
    consumedRefreshJtis.add(decoded.jti)
    // Cap the set size (prevent unbounded growth — keep last 10000)
    if (consumedRefreshJtis.size > 10000) {
      const first = consumedRefreshJtis.values().next().value
      if (first) consumedRefreshJtis.delete(first)
    }
  }
  const user = await authRepository.findById(decoded.sub)
  if (!user) throw Errors.unauthorized('User no longer exists')
  const { token: access_token, expiresIn } = signAccessToken({ id: user.id, email: user.email, role: user.role })
  const new_refresh_token = signRefreshToken({ id: user.id, email: user.email, role: user.role })
  logger.info('auth.refresh.rotated', { userId: user.id })
  return { access_token, refresh_token: new_refresh_token, expires_in: expiresIn }
}

/** Resolve full user record for a request (used by protected routes). */
export async function resolveUser(id: string) {
  const user = await authRepository.findById(id)
  if (!user) throw Errors.unauthorized()
  return user
}

// ---- Forgot / reset password (ADR #A7) ----
const RESET_TTL_MS = 15 * 60 * 1000 // 15 minutes

async function sha256(s: string): Promise<string> {
  const { createHash } = await import('crypto')
  return createHash('sha256').update(s).digest('hex')
}

/**
 * POST /auth/forgot-password — request a password reset. Always returns 200
 * (never reveals whether the email exists — Doc 1 §9 no user enumeration).
 * In dev/sandbox the reset token is returned in the response so the demo can
 * complete the flow without a real email; in production it would be emailed
 * via SES and the response would only confirm the request was received.
 */
export async function forgotPassword(email: string) {
  const user = await authRepository.findByEmail(email)
  if (!user) {
    logger.info('auth.forgot.no-user', { email: '(redacted)' })
    return { requested: true, reset_token: null as string | null }
  }
  // Generate a random token (32 bytes hex). Store only its hash.
  const { randomBytes } = await import('crypto')
  const token = randomBytes(32).toString('hex')
  const tokenHash = await sha256(token)
  await db.passwordReset.create({
    data: {
      userId: user.id,
      tokenHash,
      expiresAt: new Date(Date.now() + RESET_TTL_MS),
    },
  })
  // Mock email: console log (token HASH only — never log the plaintext token per Doc 1 §9).
  console.log(`[SES] password-reset email sent to ${user.email} (token hash: ${tokenHash.slice(0, 8)}…)`)
  logger.info('auth.forgot.issued', { userId: user.id })
  const isDev = process.env.NODE_ENV !== 'production'
  return { requested: true, reset_token: isDev ? token : null }
}

/**
 * POST /auth/reset-password — verify the reset token + set a new password.
 * Token must be valid, unexpired, unconsumed. Single-use (consumedAt set).
 */
export async function resetPassword(token: string, newPassword: string) {
  const tokenHash = await sha256(token)
  const reset = await db.passwordReset.findUnique({ where: { tokenHash } })
  if (!reset) throw Errors.badRequest('Invalid or unknown reset token')
  if (reset.consumedAt) throw Errors.badRequest('Reset token already used')
  if (reset.expiresAt.getTime() < Date.now()) throw Errors.badRequest('Reset token expired')
  const user = await authRepository.findById(reset.userId)
  if (!user) throw Errors.badRequest('User no longer exists')
  const passwordHash = await hashPassword(newPassword)
  await db.$transaction([
    db.user.update({ where: { id: user.id }, data: { passwordHash } }),
    db.passwordReset.update({ where: { id: reset.id }, data: { consumedAt: new Date() } }),
  ])
  logger.info('auth.reset.success', { userId: user.id })
  return { reset: true }
}

export { ACCESS_TTL }
