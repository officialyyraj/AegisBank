// src/modules/kyc/service.ts — KYC upload + admin review (Doc 2 §3).
//
// File storage: Doc 1 §9 says S3 (private bucket, signed URLs). The sandbox
// has no S3, so files are written to `public/kyc-uploads/users/{userId}/...`
// and the `s3_key` records that path. The CDK stack in infrastructure/cdk
// provisions the real S3 bucket for production — the service code path is
// identical except for the storage backend (controlled by KYC_UPLOAD_DIR env).
import { kycRepository } from './repository'
import { publishEventStandalone } from '@/modules/eventbus/outbox'
import { Errors } from '@/lib/errors'
import { logger } from '@/lib/logger'
import { randomUUID } from 'crypto'
import { mkdir, writeFile } from 'fs/promises'
import { join } from 'path'
import { db } from '@/lib/db'

const ALLOWED = new Set(['application/pdf', 'image/jpeg', 'image/png'])
const MAX_BYTES = 5 * 1024 * 1024 // 5MB (Doc 1 §9)

function extFor(mime: string): string {
  if (mime === 'application/pdf') return 'pdf'
  if (mime === 'image/jpeg') return 'jpg'
  if (mime === 'image/png') return 'png'
  return 'bin'
}

/** POST /kyc/documents — multipart upload. */
export async function uploadDocument(
  userId: string,
  file: { name: string; type: string; size: number; bytes: ArrayBuffer },
  docType: string,
) {
  if (!ALLOWED.has(file.type)) {
    throw Errors.badRequest('Unsupported file type (pdf/jpg/png only)')
  }
  if (file.size > MAX_BYTES) {
    throw Errors.badRequest('File too large (max 5MB)')
  }
  const uploadDir = process.env.KYC_UPLOAD_DIR || 'public/kyc-uploads'
  const ext = extFor(file.type)
  const s3Key = `users/${userId}/${randomUUID()}.${ext}`
  const localPath = join(process.cwd(), uploadDir, s3Key)
  await mkdir(join(process.cwd(), uploadDir, `users/${userId}`), { recursive: true })
  await writeFile(localPath, Buffer.from(file.bytes))
  logger.info('kyc.upload', { userId, docType, s3Key, bytes: file.size })

  const doc = await kycRepository.create({ userId, docType, s3Key, status: 'pending' })
  return { document_id: doc.id, status: doc.status }
}

/** GET /kyc/status — return the user's current kyc_status. */
export async function getStatus(userId: string) {
  const user = await db.user.findUnique({ where: { id: userId }, select: { kycStatus: true } })
  if (!user) throw Errors.unauthorized()
  return { kyc_status: user.kycStatus }
}

/** POST /kyc/documents/:id/review (admin) — approve/reject. */
export async function reviewDocument(id: string, decision: 'approved' | 'rejected') {
  const doc = await kycRepository.findById(id)
  if (!doc) return null
  const updated = await kycRepository.updateStatus(id, { status: decision, reviewedAt: new Date() })
  if (decision === 'approved') {
    await kycRepository.setUserKycStatus(doc.userId, 'approved')
  }
  await publishEventStandalone('kyc.status_changed', {
    document_id: doc.id,
    user_id: doc.userId,
    status: decision,
  })
  logger.info('kyc.reviewed', { documentId: doc.id, decision })
  return { status: updated.status }
}

/** GET /admin/kyc-documents?status=pending (admin) — review queue. */
export async function listKycDocumentsForAdmin(status?: string) {
  const docs = await kycRepository.listForAdmin(status)
  return docs.map((d) => ({
    id: d.id,
    user_id: d.userId,
    user_email: d.user.email,
    user_name: d.user.fullName,
    doc_type: d.docType,
    s3_key: d.s3Key,
    status: d.status,
    submitted_at: d.submittedAt.toISOString(),
    reviewed_at: d.reviewedAt?.toISOString() || null,
  }))
}
